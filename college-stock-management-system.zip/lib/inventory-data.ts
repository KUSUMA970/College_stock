export type Category =
  | "Microscopes"
  | "Glassware"
  | "Electronics"
  | "Measurement"
  | "Safety Gear"
  | "Computers"
  | "Chemicals"

export type Department =
  | "Biology"
  | "Chemistry"
  | "Physics"
  | "Computer Science"
  | "Electronics Engineering"

export type EquipmentStatus = "available" | "low" | "out"

export type EquipmentItem = {
  id: string
  name: string
  category: Category
  department: Department
  location: string
  total: number
  available: number
  reorderLevel: number
  unitValue: number
}

export type TransactionType = "issue" | "return"

export type Transaction = {
  id: string
  itemId: string
  itemName: string
  type: TransactionType
  quantity: number
  person: string
  role: "Student" | "Faculty" | "Lab Assistant"
  date: string
  note?: string
}

export const CATEGORIES: Category[] = [
  "Microscopes",
  "Glassware",
  "Electronics",
  "Measurement",
  "Safety Gear",
  "Computers",
  "Chemicals",
]

export const DEPARTMENTS: Department[] = [
  "Biology",
  "Chemistry",
  "Physics",
  "Computer Science",
  "Electronics Engineering",
]

export function statusOf(item: EquipmentItem): EquipmentStatus {
  if (item.available <= 0) return "out"
  if (item.available <= item.reorderLevel) return "low"
  return "available"
}

export const INITIAL_ITEMS: EquipmentItem[] = [
  {
    id: "EQ-1001",
    name: "Compound Microscope",
    category: "Microscopes",
    department: "Biology",
    location: "Bio Lab A · Shelf 3",
    total: 24,
    available: 18,
    reorderLevel: 6,
    unitValue: 420,
  },
  {
    id: "EQ-1002",
    name: "Digital Multimeter",
    category: "Electronics",
    department: "Electronics Engineering",
    location: "EE Lab 2 · Cabinet 1",
    total: 40,
    available: 5,
    reorderLevel: 8,
    unitValue: 65,
  },
  {
    id: "EQ-1003",
    name: "Beaker Set (500ml)",
    category: "Glassware",
    department: "Chemistry",
    location: "Chem Lab · Rack B",
    total: 120,
    available: 92,
    reorderLevel: 30,
    unitValue: 12,
  },
  {
    id: "EQ-1004",
    name: "Oscilloscope",
    category: "Electronics",
    department: "Electronics Engineering",
    location: "EE Lab 1 · Bench 4",
    total: 12,
    available: 2,
    reorderLevel: 4,
    unitValue: 890,
  },
  {
    id: "EQ-1005",
    name: "Safety Goggles",
    category: "Safety Gear",
    department: "Chemistry",
    location: "Chem Lab · Entrance",
    total: 200,
    available: 140,
    reorderLevel: 50,
    unitValue: 8,
  },
  {
    id: "EQ-1006",
    name: "Vernier Caliper",
    category: "Measurement",
    department: "Physics",
    location: "Physics Lab · Drawer 7",
    total: 60,
    available: 0,
    reorderLevel: 15,
    unitValue: 35,
  },
  {
    id: "EQ-1007",
    name: "Lab Workstation PC",
    category: "Computers",
    department: "Computer Science",
    location: "CS Lab 3 · Row 2",
    total: 45,
    available: 41,
    reorderLevel: 5,
    unitValue: 720,
  },
  {
    id: "EQ-1008",
    name: "Bunsen Burner",
    category: "Glassware",
    department: "Chemistry",
    location: "Chem Lab · Rack C",
    total: 50,
    available: 12,
    reorderLevel: 15,
    unitValue: 22,
  },
  {
    id: "EQ-1009",
    name: "Function Generator",
    category: "Electronics",
    department: "Physics",
    location: "Physics Lab · Bench 2",
    total: 15,
    available: 9,
    reorderLevel: 4,
    unitValue: 310,
  },
  {
    id: "EQ-1010",
    name: "pH Meter",
    category: "Measurement",
    department: "Chemistry",
    location: "Chem Lab · Rack A",
    total: 18,
    available: 3,
    reorderLevel: 5,
    unitValue: 145,
  },
  {
    id: "EQ-1011",
    name: "Petri Dish (pack)",
    category: "Glassware",
    department: "Biology",
    location: "Bio Lab B · Shelf 1",
    total: 300,
    available: 210,
    reorderLevel: 80,
    unitValue: 4,
  },
  {
    id: "EQ-1012",
    name: "Soldering Station",
    category: "Electronics",
    department: "Electronics Engineering",
    location: "EE Lab 2 · Bench 6",
    total: 20,
    available: 7,
    reorderLevel: 6,
    unitValue: 180,
  },
]

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: "TXN-5001",
    itemId: "EQ-1001",
    itemName: "Compound Microscope",
    type: "issue",
    quantity: 4,
    person: "Aditi Sharma",
    role: "Student",
    date: "2026-09-16",
    note: "Genetics practical",
  },
  {
    id: "TXN-5002",
    itemId: "EQ-1002",
    itemName: "Digital Multimeter",
    type: "issue",
    quantity: 6,
    person: "Dr. Rakesh Menon",
    role: "Faculty",
    date: "2026-09-16",
  },
  {
    id: "TXN-5003",
    itemId: "EQ-1003",
    itemName: "Beaker Set (500ml)",
    type: "return",
    quantity: 10,
    person: "Priya Nair",
    role: "Lab Assistant",
    date: "2026-09-15",
    note: "Returned after titration lab",
  },
  {
    id: "TXN-5004",
    itemId: "EQ-1007",
    itemName: "Lab Workstation PC",
    type: "issue",
    quantity: 2,
    person: "Karan Verma",
    role: "Student",
    date: "2026-09-15",
  },
  {
    id: "TXN-5005",
    itemId: "EQ-1005",
    itemName: "Safety Goggles",
    type: "issue",
    quantity: 30,
    person: "Dr. Sunita Rao",
    role: "Faculty",
    date: "2026-09-14",
    note: "First-year orientation",
  },
]

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(value)
}
