import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  CATEGORIES,
  DEPARTMENTS,
  formatCurrency,
  statusOf,
  type EquipmentItem,
  type Transaction,
} from "@/lib/inventory-data"

type Props = {
  items: EquipmentItem[]
  transactions: Transaction[]
}

function Bar({ label, value, max, caption }: { label: string; value: number; max: number; caption: string }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium">{label}</span>
        <span className="tabular-nums text-muted-foreground">{caption}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-secondary">
        <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}

export function ReportsView({ items, transactions }: Props) {
  const byDepartment = DEPARTMENTS.map((dept) => {
    const deptItems = items.filter((i) => i.department === dept)
    const units = deptItems.reduce((sum, i) => sum + i.total, 0)
    const value = deptItems.reduce((sum, i) => sum + i.available * i.unitValue, 0)
    return { dept, units, value }
  }).filter((d) => d.units > 0)

  const byCategory = CATEGORIES.map((cat) => {
    const catItems = items.filter((i) => i.category === cat)
    const units = catItems.reduce((sum, i) => sum + i.total, 0)
    return { cat, units }
  }).filter((c) => c.units > 0)

  const maxDeptUnits = Math.max(...byDepartment.map((d) => d.units), 1)
  const maxCatUnits = Math.max(...byCategory.map((c) => c.units), 1)

  const issued = transactions.filter((t) => t.type === "issue").reduce((s, t) => s + t.quantity, 0)
  const returned = transactions.filter((t) => t.type === "return").reduce((s, t) => s + t.quantity, 0)
  const outOfStock = items.filter((i) => statusOf(i) === "out").length
  const lowStock = items.filter((i) => statusOf(i) === "low").length

  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Equipment by department</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {byDepartment.map((d) => (
              <Bar
                key={d.dept}
                label={d.dept}
                value={d.units}
                max={maxDeptUnits}
                caption={`${d.units} units · ${formatCurrency(d.value)}`}
              />
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Equipment by category</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {byCategory.map((c) => (
              <Bar key={c.cat} label={c.cat} value={c.units} max={maxCatUnits} caption={`${c.units} units`} />
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Activity summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-lg border p-4">
              <p className="text-sm text-muted-foreground">Total issued</p>
              <p className="text-2xl font-semibold tabular-nums">{issued}</p>
            </div>
            <div className="rounded-lg border p-4">
              <p className="text-sm text-muted-foreground">Total returned</p>
              <p className="text-2xl font-semibold tabular-nums">{returned}</p>
            </div>
            <div className="rounded-lg border p-4">
              <p className="text-sm text-muted-foreground">Low stock items</p>
              <p className="text-2xl font-semibold tabular-nums text-amber-600 dark:text-amber-400">{lowStock}</p>
            </div>
            <div className="rounded-lg border p-4">
              <p className="text-sm text-muted-foreground">Out of stock items</p>
              <p className="text-2xl font-semibold tabular-nums text-red-600 dark:text-red-400">{outOfStock}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
