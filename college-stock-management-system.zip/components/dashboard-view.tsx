import { Boxes, PackageCheck, AlertTriangle, DollarSign, ArrowDownLeft, ArrowUpRight } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { StatCard } from "@/components/stat-card"
import { StatusBadge } from "@/components/status-badge"
import {
  formatCurrency,
  statusOf,
  type EquipmentItem,
  type Transaction,
} from "@/lib/inventory-data"

type Props = {
  items: EquipmentItem[]
  transactions: Transaction[]
}

export function DashboardView({ items, transactions }: Props) {
  const totalUnits = items.reduce((sum, i) => sum + i.total, 0)
  const availableUnits = items.reduce((sum, i) => sum + i.available, 0)
  const issuedUnits = totalUnits - availableUnits
  const lowOrOut = items.filter((i) => statusOf(i) !== "available")
  const totalValue = items.reduce((sum, i) => sum + i.available * i.unitValue, 0)
  const recent = transactions.slice(0, 6)

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total equipment" value={String(totalUnits)} hint={`${items.length} item types`} icon={Boxes} />
        <StatCard
          label="Currently issued"
          value={String(issuedUnits)}
          hint={`${availableUnits} available`}
          icon={PackageCheck}
        />
        <StatCard
          label="Needs attention"
          value={String(lowOrOut.length)}
          hint="Low or out of stock"
          icon={AlertTriangle}
          tone={lowOrOut.length > 0 ? "warning" : "default"}
        />
        <StatCard label="Inventory value" value={formatCurrency(totalValue)} hint="Available stock" icon={DollarSign} />
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="size-4 text-amber-500" aria-hidden="true" />
              Low-stock alerts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {lowOrOut.length === 0 ? (
              <p className="text-sm text-muted-foreground">All equipment is above its reorder level.</p>
            ) : (
              lowOrOut.map((item) => {
                const pct = Math.round((item.available / item.total) * 100)
                return (
                  <div key={item.id} className="space-y-1.5">
                    <div className="flex items-center justify-between gap-3 text-sm">
                      <div className="min-w-0">
                        <p className="truncate font-medium">{item.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {item.department} · reorder at {item.reorderLevel}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="tabular-nums text-muted-foreground">
                          {item.available}/{item.total}
                        </span>
                        <StatusBadge status={statusOf(item)} />
                      </div>
                    </div>
                    <Progress value={pct} className="h-1.5" />
                  </div>
                )
              })
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Recent activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {recent.map((tx) => (
              <div key={tx.id} className="flex items-start gap-3">
                <div
                  className={
                    "mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full " +
                    (tx.type === "issue"
                      ? "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400"
                      : "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400")
                  }
                >
                  {tx.type === "issue" ? (
                    <ArrowUpRight className="size-4" aria-hidden="true" />
                  ) : (
                    <ArrowDownLeft className="size-4" aria-hidden="true" />
                  )}
                </div>
                <div className="min-w-0 text-sm">
                  <p className="truncate font-medium">
                    {tx.type === "issue" ? "Issued" : "Returned"} {tx.quantity}× {tx.itemName}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {tx.person} · {tx.date}
                  </p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
