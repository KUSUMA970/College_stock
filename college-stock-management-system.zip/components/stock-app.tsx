"use client"

import { useState } from "react"
import {
  LayoutDashboard,
  Boxes,
  ArrowLeftRight,
  BarChart3,
  ArrowUpRight,
  ArrowDownLeft,
  FlaskConical,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import {
  INITIAL_ITEMS,
  INITIAL_TRANSACTIONS,
  type EquipmentItem,
  type Transaction,
  type TransactionType,
} from "@/lib/inventory-data"
import { DashboardView } from "@/components/dashboard-view"
import { InventoryView } from "@/components/inventory-view"
import { TransactionsView } from "@/components/transactions-view"
import { ReportsView } from "@/components/reports-view"
import { IssueReturnDialog } from "@/components/issue-return-dialog"

type Tab = "dashboard" | "inventory" | "transactions" | "reports"

const nav: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "inventory", label: "Inventory", icon: Boxes },
  { id: "transactions", label: "Issue & Return", icon: ArrowLeftRight },
  { id: "reports", label: "Reports", icon: BarChart3 },
]

const tabTitles: Record<Tab, { title: string; subtitle: string }> = {
  dashboard: { title: "Dashboard", subtitle: "Lab & equipment inventory overview" },
  inventory: { title: "Inventory", subtitle: "Browse and filter all lab equipment" },
  transactions: { title: "Issue & Return", subtitle: "Track equipment checked out and returned" },
  reports: { title: "Reports", subtitle: "Distribution and activity insights" },
}

export function StockApp() {
  const [tab, setTab] = useState<Tab>("dashboard")
  const [items, setItems] = useState<EquipmentItem[]>(INITIAL_ITEMS)
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS)
  const [dialogMode, setDialogMode] = useState<TransactionType | null>(null)

  function handleTransaction(data: Omit<Transaction, "id" | "date" | "itemName">) {
    const item = items.find((i) => i.id === data.itemId)
    if (!item) return

    setItems((prev) =>
      prev.map((i) =>
        i.id === data.itemId
          ? {
              ...i,
              available:
                data.type === "issue"
                  ? i.available - data.quantity
                  : i.available + data.quantity,
            }
          : i,
      ),
    )

    const tx: Transaction = {
      ...data,
      id: `TXN-${Math.floor(Math.random() * 90000) + 10000}`,
      date: new Date().toISOString().slice(0, 10),
      itemName: item.name,
    }
    setTransactions((prev) => [tx, ...prev])
  }

  const { title, subtitle } = tabTitles[tab]

  return (
    <div className="flex min-h-svh bg-background">
      <aside className="hidden w-60 shrink-0 flex-col border-r bg-sidebar md:flex">
        <div className="flex items-center gap-2.5 border-b px-5 py-4">
          <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <FlaskConical className="size-5" aria-hidden="true" />
          </div>
          <div className="leading-tight">
            <p className="text-sm font-semibold">LabStock</p>
            <p className="text-xs text-muted-foreground">College Inventory</p>
          </div>
        </div>
        <nav className="flex flex-1 flex-col gap-1 p-3">
          {nav.map((n) => (
            <button
              key={n.id}
              onClick={() => setTab(n.id)}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                tab === n.id
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-foreground",
              )}
            >
              <n.icon className="size-4" aria-hidden="true" />
              {n.label}
            </button>
          ))}
        </nav>
        <div className="border-t p-3 text-xs text-muted-foreground">Demo data · resets on reload</div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-10 flex flex-col gap-3 border-b bg-background/95 px-4 py-3 backdrop-blur sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div>
            <h1 className="text-lg font-semibold tracking-tight">{title}</h1>
            <p className="text-sm text-muted-foreground">{subtitle}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setDialogMode("return")}>
              <ArrowDownLeft className="size-4" aria-hidden="true" />
              Return
            </Button>
            <Button size="sm" onClick={() => setDialogMode("issue")}>
              <ArrowUpRight className="size-4" aria-hidden="true" />
              Issue equipment
            </Button>
          </div>
        </header>

        <nav className="flex gap-1 overflow-x-auto border-b px-2 py-2 md:hidden">
          {nav.map((n) => (
            <button
              key={n.id}
              onClick={() => setTab(n.id)}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                tab === n.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent",
              )}
            >
              <n.icon className="size-4" aria-hidden="true" />
              {n.label}
            </button>
          ))}
        </nav>

        <main className="flex-1 p-4 sm:p-6">
          {tab === "dashboard" && <DashboardView items={items} transactions={transactions} />}
          {tab === "inventory" && <InventoryView items={items} />}
          {tab === "transactions" && <TransactionsView transactions={transactions} />}
          {tab === "reports" && <ReportsView items={items} transactions={transactions} />}
        </main>
      </div>

      <IssueReturnDialog
        open={dialogMode !== null}
        onOpenChange={(o) => setDialogMode(o ? dialogMode : null)}
        mode={dialogMode ?? "issue"}
        items={items}
        onSubmit={handleTransaction}
      />
    </div>
  )
}
