"use client"

import { useMemo, useState } from "react"
import { ArrowDownLeft, ArrowUpRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import type { Transaction } from "@/lib/inventory-data"

export function TransactionsView({ transactions }: { transactions: Transaction[] }) {
  const [filter, setFilter] = useState("all")

  const filtered = useMemo(
    () => transactions.filter((t) => filter === "all" || t.type === filter),
    [transactions, filter],
  )

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-4 space-y-0">
        <CardTitle className="text-base">Issue &amp; return log</CardTitle>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All activity</SelectItem>
            <SelectItem value="issue">Issued only</SelectItem>
            <SelectItem value="return">Returned only</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Type</TableHead>
                <TableHead>Equipment</TableHead>
                <TableHead>Person</TableHead>
                <TableHead>Role</TableHead>
                <TableHead className="text-right">Qty</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Note</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                    No transactions recorded yet.
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell>
                      <Badge
                        variant="secondary"
                        className={
                          "gap-1 border-0 font-medium " +
                          (tx.type === "issue"
                            ? "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400"
                            : "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400")
                        }
                      >
                        {tx.type === "issue" ? (
                          <ArrowUpRight className="size-3" aria-hidden="true" />
                        ) : (
                          <ArrowDownLeft className="size-3" aria-hidden="true" />
                        )}
                        {tx.type === "issue" ? "Issued" : "Returned"}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-medium">{tx.itemName}</TableCell>
                    <TableCell>{tx.person}</TableCell>
                    <TableCell className="text-muted-foreground">{tx.role}</TableCell>
                    <TableCell className="text-right tabular-nums">{tx.quantity}</TableCell>
                    <TableCell className="text-muted-foreground">{tx.date}</TableCell>
                    <TableCell className="max-w-40 truncate text-muted-foreground">{tx.note ?? "—"}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
