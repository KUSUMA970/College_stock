import { Badge } from "@/components/ui/badge"
import type { EquipmentStatus } from "@/lib/inventory-data"
import { cn } from "@/lib/utils"

const config: Record<EquipmentStatus, { label: string; className: string }> = {
  available: {
    label: "In stock",
    className: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400",
  },
  low: {
    label: "Low stock",
    className: "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400",
  },
  out: {
    label: "Out of stock",
    className: "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400",
  },
}

export function StatusBadge({ status }: { status: EquipmentStatus }) {
  const { label, className } = config[status]
  return (
    <Badge variant="secondary" className={cn("border-0 font-medium", className)}>
      {label}
    </Badge>
  )
}
