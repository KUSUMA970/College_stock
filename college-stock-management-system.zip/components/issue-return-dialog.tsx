"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import type { EquipmentItem, Transaction, TransactionType } from "@/lib/inventory-data"

type Props = {
  open: boolean
  onOpenChange: (open: boolean) => void
  mode: TransactionType
  items: EquipmentItem[]
  onSubmit: (tx: Omit<Transaction, "id" | "date" | "itemName">) => void
}

const roles: Transaction["role"][] = ["Student", "Faculty", "Lab Assistant"]

export function IssueReturnDialog({ open, onOpenChange, mode, items, onSubmit }: Props) {
  const [itemId, setItemId] = useState("")
  const [quantity, setQuantity] = useState("1")
  const [person, setPerson] = useState("")
  const [role, setRole] = useState<Transaction["role"]>("Student")
  const [note, setNote] = useState("")
  const [error, setError] = useState("")

  const selected = items.find((i) => i.id === itemId)
  const isIssue = mode === "issue"

  function reset() {
    setItemId("")
    setQuantity("1")
    setPerson("")
    setRole("Student")
    setNote("")
    setError("")
  }

  function handleSubmit() {
    const qty = Number.parseInt(quantity, 10)
    if (!itemId) return setError("Please select an item.")
    if (!person.trim()) return setError("Please enter a name.")
    if (!Number.isInteger(qty) || qty <= 0) return setError("Quantity must be a positive whole number.")
    if (isIssue && selected && qty > selected.available) {
      return setError(`Only ${selected.available} unit(s) available to issue.`)
    }
    if (!isIssue && selected && selected.available + qty > selected.total) {
      return setError(`Cannot return more than ${selected.total - selected.available} issued unit(s).`)
    }
    onSubmit({ itemId, quantity: qty, person: person.trim(), role, type: mode, note: note.trim() || undefined })
    reset()
    onOpenChange(false)
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) reset()
        onOpenChange(o)
      }}
    >
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isIssue ? "Issue equipment" : "Return equipment"}</DialogTitle>
          <DialogDescription>
            {isIssue
              ? "Record equipment checked out from the lab inventory."
              : "Record equipment returned back to the lab inventory."}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label htmlFor="item">Equipment</Label>
            <Select value={itemId} onValueChange={setItemId}>
              <SelectTrigger id="item">
                <SelectValue placeholder="Select equipment" />
              </SelectTrigger>
              <SelectContent>
                {items.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name} · {item.department}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selected ? (
              <p className="text-xs text-muted-foreground">
                {selected.available} of {selected.total} available · {selected.location}
              </p>
            ) : null}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                min={1}
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="role">Role</Label>
              <Select value={role} onValueChange={(v) => setRole(v as Transaction["role"])}>
                <SelectTrigger id="role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((r) => (
                    <SelectItem key={r} value={r}>
                      {r}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="person">{isIssue ? "Issued to" : "Returned by"}</Label>
            <Input
              id="person"
              placeholder="Full name"
              value={person}
              onChange={(e) => setPerson(e.target.value)}
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="note">Note (optional)</Label>
            <Input
              id="note"
              placeholder="Purpose or remarks"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>

          {error ? <p className="text-sm text-destructive">{error}</p> : null}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>{isIssue ? "Issue" : "Return"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
